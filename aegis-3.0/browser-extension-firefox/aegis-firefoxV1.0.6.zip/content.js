const ICON_URL = chrome.runtime.getURL('icon.png');
let activeInput = null;
let aegisBtn = null;
let dropdown = null;

// Tarayıcıdaki şifre alanlarını bul ve işaretle
function scanInputs() {
    // Detect passwords, card numbers, and common identity fields
    const selectors = [
        'input[type="password"]',
        'input[autocomplete*="cc-"]',
        'input[autocomplete*="address-"]',
        'input[name*="cardnumber" i]',
        'input[id*="cardnumber" i]',
        'input[name*="cvc" i]',
        'input[name*="postal" i]',
        'input[name*="zip" i]'
    ];

    const inputs = document.querySelectorAll(selectors.join(','));
    inputs.forEach(input => {
        if (input.dataset.aegisTagged) return;
        input.dataset.aegisTagged = "true";

        input.addEventListener('focus', showIcon);
        input.addEventListener('blur', (e) => {
            setTimeout(() => {
                if (document.activeElement !== input) hideIcon();
            }, 200);
        });
    });
}

function createAegisButton() {
    if (aegisBtn) return;
    aegisBtn = document.createElement('div');
    aegisBtn.id = 'aegis-autofill-btn';
    aegisBtn.style.cssText = `
    position: absolute;
    width: 24px;
    height: 24px;
    background-image: url('${ICON_URL}');
    background-size: contain;
    background-repeat: no-repeat;
    cursor: pointer;
    z-index: 2147483647;
    display: none;
    opacity: 0.8;
    transition: opacity 0.2s;
  `;
    aegisBtn.onmouseover = () => aegisBtn.style.opacity = '1';
    aegisBtn.onmouseout = () => aegisBtn.style.opacity = '0.8';
    aegisBtn.onmousedown = (e) => {
        e.preventDefault(); // Focus kaybını önle
        handleAegisClick();
    };
    document.body.appendChild(aegisBtn);
}

function createDropdown() {
    if (dropdown) return;
    dropdown = document.createElement('div');
    dropdown.id = 'aegis-autofill-dropdown';
    dropdown.style.cssText = `
    position: absolute;
    min-width: 200px;
    background: #1a1a1a;
    color: white;
    border: 1px solid #333;
    border-radius: 6px;
    box-shadow: 0 4px 6px rgba(0,0,0,0.3);
    z-index: 2147483647;
    display: none;
    font-family: sans-serif;
    font-size: 13px;
    overflow: hidden;
  `;
    document.body.appendChild(dropdown);
}

function showIcon(e) {
    if (!aegisBtn) createAegisButton();
    if (!dropdown) createDropdown();

    activeInput = e.target;
    const rect = activeInput.getBoundingClientRect();
    const scrollX = window.scrollX;
    const scrollY = window.scrollY;

    aegisBtn.style.display = 'block';
    // Inputun sağ tarafının biraz içi
    aegisBtn.style.left = (rect.right + scrollX - 30) + 'px';
    aegisBtn.style.top = (rect.top + scrollY + (rect.height - 24) / 2) + 'px';
}

function hideIcon() {
    // Eğer dropdown açıksa gizleme
    if (dropdown && dropdown.style.display === 'block') return;
    if (aegisBtn) aegisBtn.style.display = 'none';
}

function handleAegisClick() {
    if (!activeInput) return;

    // Basit yükleniyor mesajı
    dropdown.textContent = '';
    const loadingDiv = document.createElement('div');
    loadingDiv.style.padding = '10px';
    loadingDiv.style.color = '#aaa';
    loadingDiv.textContent = 'Searching vault...';
    dropdown.appendChild(loadingDiv);
    showDropdownUI();

    const domain = window.location.hostname;

    chrome.runtime.sendMessage({
        type: 'SEND_NATIVE',
        payload: {
            id: Date.now(),
            type: 'SEARCH',
            query: domain
        }
    });
}

function showDropdownUI() {
    if (!aegisBtn || !dropdown) return;
    const rect = aegisBtn.getBoundingClientRect();
    const scrollX = window.scrollX;
    const scrollY = window.scrollY;

    dropdown.style.display = 'block';
    dropdown.style.left = (rect.left + scrollX) + 'px';
    dropdown.style.top = (rect.bottom + scrollY + 5) + 'px';
}

// Background'dan gelen mesajları dinle
chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'NATIVE_RESPONSE') {
        const payload = msg.data;
        // Search sonucu
        if (Array.isArray(payload.data)) {
            renderSearchResults(payload.data);
        }
        // Credential sonucu (Deep Autofill)
        else if (payload.data) {
            fillEntry(payload.data);
        }
        else if (payload.error) {
            dropdown.textContent = '';
            const errorDiv = document.createElement('div');
            errorDiv.style.padding = '10px';
            errorDiv.style.color = '#ef4444';
            errorDiv.textContent = `Error: ${payload.error}`;
            dropdown.appendChild(errorDiv);
        }
    }
});

function renderSearchResults(results) {
    if (!dropdown) return;

    if (results.length === 0) {
        dropdown.textContent = '';
        const emptyDiv = document.createElement('div');
        emptyDiv.style.padding = '10px';
        emptyDiv.style.color = '#aaa';
        emptyDiv.textContent = 'No entries found for this domain.';
        dropdown.appendChild(emptyDiv);
        setTimeout(() => { dropdown.style.display = 'none'; }, 2000);
        return;
    }

    dropdown.textContent = '';
    results.forEach(entry => {
        const item = document.createElement('div');
        item.style.cssText = `
            padding: 10px;
            border-bottom: 1px solid #333;
            cursor: pointer;
            display: flex;
            flex-direction: column;
        `;
        item.onmouseover = () => item.style.background = '#333';
        item.onmouseout = () => item.style.background = 'transparent';

        const title = document.createElement('div');
        title.innerText = entry.title;
        title.style.fontWeight = 'bold';

        const user = document.createElement('div');
        user.innerText = entry.username || 'No Username';
        user.style.fontSize = '11px';
        user.style.color = '#aaa';

        item.appendChild(title);
        item.appendChild(user);

        item.onmousedown = (e) => { // prevent blur
            e.preventDefault();
            requestCredential(entry.id);
        };

        dropdown.appendChild(item);
    });
}

function requestCredential(entryId) {
    dropdown.textContent = '';
    const decryptDiv = document.createElement('div');
    decryptDiv.style.padding = '10px';
    decryptDiv.style.color = '#aaa';
    decryptDiv.textContent = 'Decrypting...';
    dropdown.appendChild(decryptDiv);
    chrome.runtime.sendMessage({
        type: 'SEND_NATIVE',
        payload: {
            id: Date.now(),
            type: 'GET_CREDENTIALS',
            entryId: entryId
        }
    });
}

function fillAny(input, value) {
    if (!input || value === undefined || value === null || value === "") return;
    input.value = value;
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
}

function fillEntry(cred) {
    if (!activeInput) return;
    const form = activeInput.form || document;
    const inputs = Array.from(form.querySelectorAll('input, select, textarea'));

    // 1. Password/Username filling (Login)
    if (cred.type === 'login' || cred.password) {
        fillAny(activeInput, cred.password);
        if (cred.username) {
            const userField = inputs.find(i =>
                (i.type === 'text' || i.type === 'email') &&
                (i.name?.toLowerCase().includes('user') || i.name?.toLowerCase().includes('email') || i.id?.toLowerCase().includes('user'))
            ) || (inputs.indexOf(activeInput) > 0 ? inputs[inputs.indexOf(activeInput) - 1] : null);

            if (userField && userField !== activeInput) fillAny(userField, cred.username);
        }
    }

    // 2. Card filling
    if (cred.card) {
        inputs.forEach(i => {
            const name = (i.name || i.id || i.placeholder || '').toLowerCase();
            const autocomp = (i.getAttribute('autocomplete') || '').toLowerCase();

            if (autocomp.includes('cc-number') || name.includes('cardnumber') || name.includes('number')) fillAny(i, cred.card.number);
            if (autocomp.includes('cc-exp') || name.includes('expiry') || name.includes('exp')) fillAny(i, cred.card.expiry);
            if (autocomp.includes('cc-csc') || name.includes('cvc') || name.includes('cvv')) fillAny(i, cred.card.cvv);
            if (autocomp.includes('cc-name') || name.includes('holder') || name.includes('owner')) fillAny(i, cred.card.holder);
        });
    }

    // 3. Identity filling
    if (cred.identity) {
        inputs.forEach(i => {
            const name = (i.name || i.id || i.placeholder || '').toLowerCase();
            const autocomp = (i.getAttribute('autocomplete') || '').toLowerCase();
            const label = document.querySelector(`label[for="${i.id}"]`)?.innerText.toLowerCase() || '';

            const match = (key) => autocomp.includes(key) || name.includes(key) || label.includes(key);

            if (match('given-name') || name.includes('firstname')) fillAny(i, cred.identity.firstName);
            else if (match('family-name') || name.includes('lastname')) fillAny(i, cred.identity.lastName);
            else if (match('name') && !match('family') && !match('given')) fillAny(i, cred.identity.fullName);

            if (match('email')) fillAny(i, cred.identity.email);
            if (match('tel') || match('phone') || match('mobile')) fillAny(i, cred.identity.phone);
            if (match('address-line1') || match('street')) fillAny(i, cred.identity.address);
            if (match('address-level2') || match('city')) fillAny(i, cred.identity.city);
            if (match('address-level1') || match('state')) fillAny(i, cred.identity.state);
            if (match('postal-code') || match('zip')) fillAny(i, cred.identity.zip);
            if (match('country')) fillAny(i, cred.identity.country);
            if (match('organization') || match('company')) fillAny(i, cred.identity.company);
            if (match('job') || match('title')) fillAny(i, cred.identity.job);
        });
    }

    // 4. Custom Fields (Deep logic)
    if (cred.customFields) {
        cred.customFields.forEach(field => {
            const target = inputs.find(i => {
                const label = document.querySelector(`label[for="${i.id}"]`)?.innerText.toLowerCase() || '';
                const name = (i.name || i.id || i.placeholder || '').toLowerCase();
                return name.includes(field.name.toLowerCase()) || label.includes(field.name.toLowerCase());
            });
            if (target) fillAny(target, field.value);
        });
    }

    if (cred.totp && inputs.find(i => i.placeholder?.toLowerCase().includes('otp') || i.name?.toLowerCase().includes('otp'))) {
        const otpField = inputs.find(i => i.placeholder?.toLowerCase().includes('otp') || i.name?.toLowerCase().includes('otp') || i.autocomplete === 'one-time-code');
        if (otpField) fillAny(otpField, cred.totp);
    }

    dropdown.style.display = 'none';
}

// Şifre Kaydetme Takibi
let lastUserCapture = "";
let lastPassCapture = "";

function setupSaveDetection() {
    document.addEventListener('input', (e) => {
        const target = e.target;
        if (target.tagName === 'INPUT') {
            if (target.type === 'password') {
                lastPassCapture = target.value;
                // Kullanıcı adını bulmaya çalış
                const form = target.form;
                if (form) {
                    const inputs = Array.from(form.querySelectorAll('input:not([type="hidden"])'));
                    const pIndex = inputs.indexOf(target);
                    for (let i = pIndex - 1; i >= 0; i--) {
                        if (inputs[i].type === 'text' || inputs[i].type === 'email') {
                            lastUserCapture = inputs[i].value;
                            break;
                        }
                    }
                }
            } else if (target.type === 'text' || target.type === 'email') {
                lastUserCapture = target.value;
            }
        }
    });

    document.addEventListener('submit', (e) => {
        if (lastPassCapture && lastPassCapture.length > 3) {
            // Şifre girilmiş ve form gönderiliyor, 1 saniye sonra sor
            setTimeout(() => {
                showSavePrompt(lastUserCapture, lastPassCapture);
            }, 1000);
        }
    });
}

function showSavePrompt(user, pass) {
    if (document.getElementById('aegis-save-banner')) return;

    const bannerLangs = navigator.language.startsWith('tr') ? {
        text: "Bu şifreyi Aegis Vault'a kaydetmek ister misiniz?",
        save: "Kaydet",
        ignore: "Yoksay",
        saved: "Kaydedildi!"
    } : {
        text: "Would you like to save this password to Aegis Vault?",
        save: "Save",
        ignore: "Ignore",
        saved: "Saved!"
    };

    const banner = document.createElement('div');
    banner.id = 'aegis-save-banner';
    banner.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        width: 350px;
        background: #1e293b;
        color: white;
        padding: 16px;
        border-radius: 12px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.5);
        z-index: 2147483647;
        font-family: sans-serif;
        display: flex;
        flex-direction: column;
        gap: 12px;
        border: 1px solid #3b82f6;
        animation: aegis-slide-in 0.3s ease-out;
    `;

    const style = document.createElement('style');
    style.textContent = `
        @keyframes aegis-slide-in { from { transform: translateX(120%); } to { transform: translateX(0); } }
        .aegis-btn-p { background: #3b82f6; color: white; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-weight: 600; }
        .aegis-btn-s { background: #334155; color: #cbd5e1; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; }
    `;
    document.head.appendChild(style);

    // Build banner structure using safe DOM methods
    const topRow = document.createElement('div');
    topRow.style.cssText = 'display:flex; align-items:center; gap:10px;';

    const icon = document.createElement('img');
    icon.src = ICON_URL;
    icon.style.cssText = 'width:24px; height:24px;';

    const title = document.createElement('div');
    title.style.cssText = 'font-weight:600; font-size:14px;';
    title.textContent = 'Aegis Vault';

    topRow.appendChild(icon);
    topRow.appendChild(title);

    const bodyText = document.createElement('div');
    bodyText.style.cssText = 'font-size:13px; color:#cbd5e1;';
    bodyText.textContent = bannerLangs.text;

    const infoBox = document.createElement('div');
    infoBox.style.cssText = 'font-size:12px; background:#0f172a; padding:8px; border-radius:4px; color:#94a3b8;';

    const userLine = document.createElement('div');
    userLine.textContent = `User: ${user || '---'}`;

    const passLine = document.createElement('div');
    passLine.textContent = 'Pass: ••••••••';

    infoBox.appendChild(userLine);
    infoBox.appendChild(passLine);

    const btnRow = document.createElement('div');
    btnRow.style.cssText = 'display:flex; gap:10px; justify-content:flex-end;';

    const ignoreBtn = document.createElement('button');
    ignoreBtn.id = 'aegis-ignore-btn';
    ignoreBtn.className = 'aegis-btn-s';
    ignoreBtn.textContent = bannerLangs.ignore;

    const saveBtn = document.createElement('button');
    saveBtn.id = 'aegis-save-btn';
    saveBtn.className = 'aegis-btn-p';
    saveBtn.textContent = bannerLangs.save;

    btnRow.appendChild(ignoreBtn);
    btnRow.appendChild(saveBtn);

    banner.appendChild(topRow);
    banner.appendChild(bodyText);
    banner.appendChild(infoBox);
    banner.appendChild(btnRow);

    document.body.appendChild(banner);

    ignoreBtn.onclick = () => banner.remove();
    saveBtn.onclick = () => {
        chrome.runtime.sendMessage({
            type: 'SEND_NATIVE',
            payload: {
                id: Date.now(),
                type: 'SAVE_ENTRY',
                title: window.location.hostname,
                username: user,
                password: pass,
                website: window.location.href
            }
        });
        const btn = document.getElementById('aegis-save-btn');
        btn.innerText = bannerLangs.saved;
        btn.style.background = '#10b981';
        setTimeout(() => banner.remove(), 2000);
    };
}

// Başlarken tara
setInterval(scanInputs, 1000);
setupSaveDetection();
