# Mozilla Add-ons Gönderim Kontrol Listesi

## 📦 Hazırlanan Paket

**Dosya:** `aegis-firefox-v1.0.1.zip`
**Boyut:** ~30 KB
**Tarih:** 2026-02-04

### ✅ Paket İçeriği:
- ✅ manifest.json (973 bytes) - Manifest V2, Firefox uyumlu
- ✅ background.js (2,290 bytes) - Browser API kullanıyor
- ✅ popup.js (13,538 bytes) - Browser API kullanıyor
- ✅ popup.html (3,723 bytes) - Popup arayüzü
- ✅ popup.css (5,573 bytes) - Stiller
- ✅ content.js (7,842 bytes) - Browser API kullanıyor
- ✅ icon.png (20,285 bytes) - 128x128 ikon

## 🚀 Mozilla Add-ons'a Gönderme Adımları

### 1. Mozilla Developer Hub'a Giriş Yapın
- URL: https://addons.mozilla.org/developers/
- Hesabınızla giriş yapın

### 2. Yeni Eklenti Yükleyin
- "Submit a New Add-on" butonuna tıklayın
- Platform: **Firefox**
- Distribution: **On this site** (veya self-distribution için "On your own")

### 3. Dosyayı Yükleyin
- `aegis-firefox-v1.0.1.zip` dosyasını yükleyin
- Otomatik validasyon başlayacak

### 4. Eklenti Bilgilerini Doldurun

#### Temel Bilgiler:
```
Name: Aegis Vault
Summary: Secure password manager bridge for Aegis Vault desktop application
Description: 
Aegis Vault browser extension provides seamless integration between 
your Firefox browser and the Aegis Vault desktop application. 
Securely autofill passwords, manage credentials, and sync across 
devices with military-grade encryption.

Features:
- Secure native messaging with desktop app
- Auto-fill passwords on websites
- QR code scanning support
- Zero-knowledge encryption
- No cloud storage - your data stays local

Requires Aegis Vault desktop application to be installed.
```

#### Kategoriler:
- Privacy & Security
- Productivity

#### Tags:
- password manager
- security
- encryption
- autofill
- privacy

### 5. Native Messaging İzni Açıklaması

Mozilla, `nativeMessaging` iznini sorguladığında şu açıklamayı yapın:

```
Native Messaging Permission Justification:

This extension requires native messaging to communicate with the 
Aegis Vault desktop application. The native messaging host is used to:

1. Securely retrieve encrypted passwords from the local vault
2. Send autofill requests to the desktop application
3. Synchronize credential data between browser and desktop app

The communication happens through a secure, localhost-only named pipe 
with session token authentication. No external servers are contacted.

The native messaging host manifest is automatically registered by the 
desktop application at: HKCU\Software\Mozilla\NativeMessagingHosts\com.aegis.vault

All data transmission is encrypted and happens only on the local machine.
```

### 6. Gizlilik Politikası

```
Privacy Policy:

Aegis Vault does not collect, store, or transmit any user data to 
external servers. All password data is:

- Stored locally on your device
- Encrypted with AES-256-GCM
- Never sent to cloud services
- Only accessible through the desktop application

The extension communicates only with the local desktop application 
via native messaging. No analytics, tracking, or telemetry is used.

For more information, visit: https://hetech-me.space
```

### 7. Lisans
- **License:** Proprietary (veya kullandığınız lisans)

### 8. Version Notes (v1.0.1)
```
Version 1.0.1 Release Notes:

- Manifest V2 for Firefox compatibility
- Browser API support for cross-browser compatibility
- Fixed native messaging connection issues
- Improved refresh functionality
- Enhanced desktop app integration
- Auto-registration of native messaging host
- User-friendly installation (no admin rights required)

This version addresses all compatibility issues with Firefox and 
provides seamless integration with the Aegis Vault desktop application.
```

## ⚠️ Önemli Notlar

### Mozilla İnceleme Süreci:
1. **Otomatik Validasyon** - Birkaç dakika
2. **Manuel İnceleme** - 1-5 iş günü
3. **Onay/Red** - Email ile bildirim

### Olası Sorular ve Cevaplar:

**Q: Neden native messaging kullanıyorsunuz?**
A: Desktop uygulaması ile güvenli iletişim için. Tüm şifre verileri local'de saklanıyor ve cloud kullanmıyoruz.

**Q: Kaynak kodu paylaşabilir misiniz?**
A: Evet, GitHub'da açık kaynak olarak paylaşılabilir veya Mozilla'ya özel olarak gönderilebilir.

**Q: Güvenlik testleri yapıldı mı?**
A: Evet, AES-256-GCM şifreleme, session token authentication ve secure pipe communication kullanılıyor.

**Q: Desktop uygulaması olmadan çalışır mı?**
A: Hayır, desktop uygulaması gereklidir. Bu durum açıkça belirtilmiştir.

## 📋 Gönderim Öncesi Kontrol Listesi

- [ ] Zip dosyası doğru içeriğe sahip
- [ ] manifest.json doğru (Manifest V2)
- [ ] Extension ID doğru: `sales@hetech-me.space`
- [ ] İkonlar dahil edildi
- [ ] Tüm dosyalar Browser API kullanıyor
- [ ] README hazır
- [ ] Gizlilik politikası hazır
- [ ] Native messaging açıklaması hazır
- [ ] Version notes hazır
- [ ] Desktop uygulaması otomatik kurulum yapıyor
- [ ] Test edildi ve çalışıyor

## 🔗 Faydalı Linkler

- Mozilla Developer Hub: https://addons.mozilla.org/developers/
- Extension Workshop: https://extensionworkshop.com/
- Native Messaging Docs: https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/Native_messaging
- Review Policies: https://extensionworkshop.com/documentation/publish/add-on-policies/

## 📞 Destek

Eğer Mozilla inceleme sürecinde sorular gelirse:
- Email: sales@hetech-me.space
- Website: https://hetech-me.space

---

**Hazırlayan:** Aegis Vault Team
**Tarih:** 2026-02-04
**Versiyon:** 1.0.1
