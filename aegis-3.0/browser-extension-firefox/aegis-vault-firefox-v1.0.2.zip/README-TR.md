# Aegis Vault Firefox Extension - Kurulum Rehberi

## 🔧 Sorun Giderme ve Düzeltmeler

Bu güncelleme ile aşağıdaki sorunlar düzeltildi:

### ✅ Düzeltilen Sorunlar:
1. **Şifre Getirme Sorunu** - Native messaging bağlantısı düzeltildi
2. **Refresh Butonu** - Artık düzgün çalışıyor
3. **Open Desktop App Butonu** - Desktop uygulamasını açıyor
4. **Manifest V2 Uyumluluğu** - Firefox için Manifest V2'ye geçildi
5. **Browser API Uyumluluğu** - Tüm Chrome API çağrıları Firefox uyumlu hale getirildi
6. **Otomatik Kurulum** - Desktop uygulama ilk çalıştığında otomatik olarak native messaging host'u kaydediyor

## 🎉 Otomatik Kurulum (Önerilen)

### Kullanıcılar İçin En Kolay Yöntem:

**Hiçbir manuel işlem gerekmez!** Desktop uygulaması ilk çalıştığında otomatik olarak:
- ✅ Native messaging host manifest dosyalarını oluşturur (Chrome ve Firefox için)
- ✅ Registry kayıtlarını yapar (HKCU - yönetici yetkisi gerektirmez)
- ✅ Gerekli tüm dosyaları hazırlar

**Sadece şunları yapın:**
1. Aegis Vault desktop uygulamasını çalıştırın (ilk çalıştırmada otomatik kurulum yapılır)
2. Firefox eklentisini kurun (`.xpi` dosyasını sürükle-bırak)
3. Kullanmaya başlayın!

## 📋 Manuel Kurulum (İsteğe Bağlı)

Desktop uygulaması otomatik kurulum yapıyor, ancak manuel olarak kontrol etmek isterseniz:

#### Geliştirme/Test İçin (Geçici Yükleme):
1. Firefox'u açın
2. Adres çubuğuna `about:debugging#/runtime/this-firefox` yazın
3. "Load Temporary Add-on" butonuna tıklayın
4. `C:\Users\hrn21\OneDrive\Desktop\aegis-son-2\aegis-vault\browser-extension-firefox\manifest.json` dosyasını seçin

#### Kalıcı Kurulum İçin (İmzalı XPI):
1. `aegis-firefox-v1.0.1.zip` dosyasını Mozilla Add-ons'a yükleyin
2. İmzalanan `.xpi` dosyasını indirin
3. Firefox'ta `.xpi` dosyasını açın veya sürükle-bırak yapın

## 🔍 Test Etme

1. **Desktop Uygulamasını Çalıştırın** - Aegis Vault desktop uygulamasının çalıştığından emin olun
2. **Vault'u Açın** - Master şifrenizi girerek vault'u açın
3. **Bir Web Sitesine Gidin** - Kayıtlı bir giriş bilgisi olan bir siteye gidin
4. **Eklenti İkonuna Tıklayın** - Tarayıcı araç çubuğundaki Aegis Vault ikonuna tıklayın
5. **Şifreleri Görün** - Kayıtlı şifrelerinizi görmelisiniz

## 🐛 Sorun Giderme

### "No connection to host" Hatası
- Desktop uygulamasının çalıştığından emin olun
- Desktop uygulamasını yeniden başlatın (otomatik kurulum yapacaktır)
- Native messaging host'un doğru kurulduğunu kontrol edin:
  ```powershell
  # HKCU (kullanıcı bazlı) registry kaydını kontrol edin
  Get-ItemProperty -Path "HKCU:\SOFTWARE\Mozilla\NativeMessagingHosts\com.aegis.vault"
  ```
- Beklenen çıktı: `(Default)` değeri manifest dosyasının yolunu göstermeli
- Manifest dosyası genellikle şurada olmalı: `%APPDATA%\aegis-vault\com.aegis.vault.firefox.json`

### Otomatik Kurulum Çalışmadıysa
Desktop uygulaması ilk çalıştığında otomatik kurulum yapmalı. Eğer yapmadıysa:
```powershell
# Manuel kurulum scripti (yönetici yetkisi GEREKTIRMEZ)
cd "browser-extension-firefox"
.\install-firefox-host.ps1
```

### Refresh Butonu Çalışmıyor
- Eklentiyi kaldırıp yeniden yükleyin
- Firefox'u yeniden başlatın
- Desktop uygulamasını yeniden başlatın

### Şifreler Görünmüyor
- Desktop uygulamasında vault'un açık olduğundan emin olun
- Browser console'u açın (F12) ve hata mesajlarını kontrol edin
- Background script console'unu kontrol edin: `about:debugging#/runtime/this-firefox`

## 📁 Dosya Yapısı

```
browser-extension-firefox/
├── manifest.json                    # Manifest V2 - Firefox uyumlu
├── background.js                    # Browser API kullanıyor
├── popup.js                         # Browser API kullanıyor
├── popup.html                       # Popup UI
├── popup.css                        # Stiller
├── content.js                       # Browser API kullanıyor
├── icon.png                         # Eklenti ikonu
├── aegis-update.json               # Otomatik güncelleme
├── aegis-firefox-v1.0.1.zip        # Paketlenmiş eklenti
└── install-firefox-host.ps1        # Native host kurulum scripti
```

## 🔐 Güvenlik Notları

- Native messaging host sadece `sales@hetech-me.space` extension ID'sine izin verir
- Tüm iletişim localhost üzerinden şifrelenmiş pipe ile yapılır
- Session token ile kimlik doğrulama yapılır

## 📝 Değişiklik Geçmişi

### v1.0.1 (2026-02-04)
- ✅ Manifest V2'ye geçiş (Firefox uyumluluğu)
- ✅ Browser API desteği eklendi
- ✅ Native messaging bağlantısı düzeltildi
- ✅ Refresh butonu düzeltildi
- ✅ Open Desktop App butonu düzeltildi
- ✅ Content script otomatik yükleme eklendi
- ✅ Firefox için ayrı native messaging manifest
- ✅ **Otomatik kurulum** - Desktop uygulama ilk çalıştığında otomatik kayıt
- ✅ **HKCU registry** - Yönetici yetkisi gerektirmez
- ✅ **Kullanıcı dostu** - Manuel işlem gerekmez

### v1.0 (İlk Sürüm)
- ❌ Manifest V3 (Firefox'ta sorunluydu)
- ❌ Chrome API kullanımı (Firefox'ta çalışmıyordu)
- ❌ Manuel kurulum gerekliydi
- ❌ Yönetici yetkisi gerekliydi

## 🆘 Destek

Sorun yaşıyorsanız:
1. Browser console'u kontrol edin (F12)
2. Background script console'unu kontrol edin (`about:debugging`)
3. Desktop uygulamasının log dosyalarını kontrol edin
4. `bridge_debug.log` dosyasını kontrol edin (Desktop'ta)

## 🚀 Sonraki Adımlar

**Otomatik Kurulum ile:**
1. Desktop uygulamasını çalıştırın (otomatik kurulum yapılır)
2. Firefox eklentisini kurun (.xpi dosyası)
3. Vault'u açın ve kullanmaya başlayın!

**Manuel kontrol için:**
- `install-firefox-host.ps1` scriptini çalıştırabilirsiniz (yönetici yetkisi gerektirmez)

---

**Not:** Bu eklenti sadece Windows'ta çalışır ve Aegis Vault desktop uygulamasının kurulu olmasını gerektirir.
