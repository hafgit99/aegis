# Version 1.0.2 Update Notes for Mozilla Reviewers

## Summary
This is a bug fix release that resolves a critical issue with the QR code scanning feature.

## What Changed
The QR code scanning functionality was not working in version 1.0.1 because the required `jsQR` library was missing from the package. This update adds the library and improves the scanning algorithm.

## Files Changed
1. **Added**: `jsQR.js` - Open source QR code library (MIT License, https://github.com/cozmo/jsQR)
2. **Modified**: `popup.html` - Added script tag to load jsQR library
3. **Modified**: `popup.js` - Enhanced QR scanning with better error handling
4. **Modified**: `manifest.json` - Version bump to 1.0.2

## Testing Instructions
1. Install the extension
2. Click the extension icon
3. Click the QR code scan button (top left)
4. Upload a QR code image
5. The QR code should be successfully detected and sent to the desktop application

## Third-Party Libraries
- **jsQR v1.4.0**: MIT License, used for QR code detection
  - Source: https://github.com/cozmo/jsQR
  - CDN: https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.js
  - Purpose: Client-side QR code scanning

## Privacy & Security
- No data is sent to external servers
- QR code scanning happens entirely in the browser
- All communication is with the local desktop application via native messaging

## Source Code
Full source code is available at: [Your GitHub Repository URL]

---

Thank you for reviewing this update!
